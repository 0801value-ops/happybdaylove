const gate=document.getElementById('nirvana-gate');
if(document.documentElement.classList.contains('nirvana-gate-active')){
  const root=document.getElementById('root');if(root)root.inert=true;
  const input=gate.querySelector('input'),error=gate.querySelector('#entry-error');
  input.focus();
  input.addEventListener('input',()=>{error.textContent='';input.removeAttribute('aria-invalid')});
  gate.querySelector('form').addEventListener('submit',event=>{
    event.preventDefault();
    if(input.value.trim().toUpperCase()!==['O','1','0','R','3'].join('')){
      error.textContent='Casi, amor. Revisa las pistas e inténtalo otra vez ♡';
      input.setAttribute('aria-invalid','true');input.select();return;
    }
    try{sessionStorage.setItem('nirvana.entry.v1','true')}catch{}
    document.documentElement.classList.remove('nirvana-gate-active');
    gate.remove();window.__nirvanaUnlock?.();
  });
}else gate?.remove();
