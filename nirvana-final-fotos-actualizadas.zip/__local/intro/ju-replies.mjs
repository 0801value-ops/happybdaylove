export const normalizeQuestion = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[¿?¡!.,]/g, '').trim()

// Jules supplied these sentiments. Ju offers a caring interpretation, not mind-reading.
export function caringReply(question, previous = '') {
  const q = normalizeQuestion(question)
  const context = q.length < 45 ? `${normalizeQuestion(previous)} ${q}` : q
  if (/cumplean|feliz cumple/.test(context)) return 'Creo que Jules te diría: «Feliz cumpleaños, amor de mi vida. Ojalá hoy puedas sentir un poquito de todo el amor con el que hice este espacio para ti». Él quiere seguir compartiendo contigo muchos cumpleaños y todos esos días sencillos que también importan.'
  if (/discut|peleam|enoj|molest|error|equivo|perdon/.test(context)) return 'Por lo que Jules ha escrito sobre ti, creo que querría escucharte y entender qué pasó. Imagino que te diría: «Te amo, y lo que sientes me importa. Hablemos con calma y busquemos cómo cuidarnos mejor». No puedo saber si está molesto ahora; preguntárselo a él les dará espacio para entenderse.'
  if (/no.*respond|no.*contesta|ocupad|demora|tarda|distante/.test(context)) return 'No puedo saber por qué Jules tarda en responder en este momento. Sí sé que a veces está trabajando o estudiando, y que él ha dicho que te ama y que eres su prioridad. Creo que te diría que puedes contarle si necesitas compañía o si algo te está haciendo sentir insegura.'
  if (/triste|llor|mal dia|dia (malo|pesado)|agotad|cansad|ansios|angust|insegur|suficiente|fracaso/.test(context)) return 'Creo que Jules te diría: «Amor, no tienes que tener todo resuelto ni estar bien todo el tiempo. Quiero escucharte y acompañarte, también en los días pesados». Él te ama por quien eres, no por cuánto logras hacer; por lo que me ha contado, estar contigo es su forma favorita de pasar la vida.'
  if (/futuro|casar|espos|boda|vida juntos|vida conmigo/.test(context)) return 'Jules ha escrito que sueña con compartir una vida contigo y que quiere caminar a tu lado. Creo que te diría: «Me hace feliz imaginar un futuro juntos, amor; quiero construirlo contigo en las cosas pequeñas de cada día». Para él, estar contigo se parece a estar en casa.'
  if (/celos|dani|newjeans|katseye|otra.*(gust|ama)|le gusto|me ama|me quiere|ama.*(mi|ella)|amor.*mi|quiere.*mi/.test(context)) return 'Jules lo ha dicho con sus propias palabras: te ama, le encanta estar contigo y eres su prioridad. Que admire a sus artistas favoritas tiene que ver con la música; él contó que románticamente solo le gustas tú. Creo que te diría: «Mi amor, eres tú la persona con la que quiero compartir mi vida».'
  if (/extran|distancia|lejos|necesito.*(abrazo|carino)|quiero.*abrazo/.test(context)) return 'Por cómo habla de ti, imagino que Jules te diría: «Yo también quiero tenerte cerquita, ver una película contigo y quedarme un ratito más a tu lado». Sé que piensa en ti al despertar y antes de dormirse. Puedes decirle que lo extrañas: tu cariño tiene un lugar muy bonito en su vida.'
  return null
}

export function offlineReply(question, previous) {
  return caringReply(question, previous) || 'Con lo que conozco de Jules, creo que lo primero que querría sería escucharte y saber cómo te sientes. Él te ama y ha escrito que quiere compartir su vida contigo. Si me cuentas un poquito más de la situación, puedo ayudarte a imaginar qué podría decirte; su respuesta real siempre puedes preguntársela a él.'
}
