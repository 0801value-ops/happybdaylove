import {offlineReply} from './ju-replies.mjs';
const juPet = await fetch('/__local/intro/ju-pet.svg').then(response => response.text())
class NirvanaJu extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return
    this.messages = []
    const root = this.attachShadow({ mode: 'open' })
    root.innerHTML = `<style>
      :host{display:block;color:#37382d;font-family:system-ui,sans-serif}*{box-sizing:border-box}
      .room{max-width:780px;margin:0 auto;padding:32px 20px 48px;text-align:center;background:radial-gradient(ellipse at 50% 55%,#f2f1e5,transparent 65%)}
      .eyebrow{font:11px monospace;letter-spacing:3px;text-transform:uppercase;color:#767868}h1{font:normal 52px Georgia,serif;margin:12px 0} .intro{max-width:550px;margin:auto;font:17px/1.6 Georgia,serif}
      .note{font-size:11px;color:#77786d;margin:14px auto 0;max-width:490px;line-height:1.5}
      .stage{min-height:310px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding:28px 0 8px}
      .speech{position:relative;max-width:540px;width:100%;padding:20px 24px;border:1px solid #dedfd2;border-radius:24px;background:#ffffffb8;box-shadow:0 8px 30px #3f453008;font:18px/1.6 Georgia,serif;text-align:left;white-space:pre-wrap;overflow-wrap:anywhere}
      .speech:after{content:'';position:absolute;bottom:-8px;left:calc(50% - 8px);width:14px;height:14px;background:#fafaf6;border-bottom:1px solid #dedfd2;border-right:1px solid #dedfd2;transform:rotate(45deg)}
      .pet{width:176px;height:187px;margin:18px auto 0;animation:breathe 3.6s ease-in-out infinite;transform-origin:50% 95%;image-rendering:pixelated;filter:drop-shadow(0 6px 0 #444b350c)}
      .eyes{animation:blink 5.2s infinite;transform-origin:32px 24px}.arm-left{transform-origin:16px 33px}.arm-right{transform-origin:48px 33px;animation:hello 7s ease-in-out infinite}.face{transform-origin:32px 24px}
      .thinking .pet{animation:ponder 2.2s ease-in-out infinite}.thinking .arm-right{animation:cuddle 2.2s ease-in-out infinite}.thinking[data-gesture="1"] .pet{animation:sway 2s ease-in-out infinite}.thinking[data-gesture="1"] .arm-left{animation:cuddle 2s ease-in-out infinite reverse}.thinking[data-gesture="2"] .face{animation:peek 2.4s ease-in-out infinite}
      .talking .pet{animation:happy .7s ease-in-out 3}.talking .arm-right{animation:hello 1.4s ease-in-out 2}.talking[data-gesture="1"] .arm-left{animation:cuddle 1s ease-in-out 3}
      @keyframes breathe{50%{transform:translateY(-3px) scale(1.025,.98)}}@keyframes ponder{50%{transform:rotate(-5deg) translateY(-2px)}}@keyframes sway{25%{transform:rotate(-4deg)}75%{transform:rotate(4deg)}}@keyframes peek{50%{transform:translate(2px,-1px)}}@keyframes happy{50%{transform:translateY(-7px) scale(.98,1.02)}80%{transform:scale(1.04,.96)}}@keyframes cuddle{50%{transform:rotate(24deg)}}@keyframes hello{0%,60%,100%{transform:rotate(0)}70%,90%{transform:rotate(-35deg)}80%{transform:rotate(-18deg)}}@keyframes blink{0%,44%,48%,100%{transform:scaleY(1)}46%{transform:scaleY(.12)}}
      .suggestions{display:flex;justify-content:center;flex-wrap:wrap;gap:8px;margin:20px 0}button{cursor:pointer;font:inherit} .suggestions button,.reset{font-size:12px;border:1px solid #dedfd2;background:#ffffff80;border-radius:20px;padding:9px 12px;color:#555847}
      form{display:flex;align-items:flex-end;gap:12px;padding:10px;background:#fff;border:1px solid #d6d8ca;border-radius:22px;box-shadow:0 6px 24px #333a1608}textarea{resize:vertical;min-height:46px;max-height:150px;width:100%;border:0;background:transparent;padding:12px;font:15px/1.5 system-ui;color:inherit}textarea:focus{outline:0}form:focus-within{outline:2px solid #a3d4ea} .send{border:0;border-radius:50%;background:#b5def1;color:#234e65;width:44px;height:44px;flex-shrink:0;font-size:22px}button:disabled{opacity:.45;cursor:wait}
      details{text-align:left;margin:24px 0;font-size:13px}summary{cursor:pointer;color:#6e725e}.history{max-height:280px;overflow:auto;line-height:1.6;overflow-wrap:anywhere}.history p{border-bottom:1px solid #dedfd2;padding:10px 0;white-space:pre-wrap}.reset{margin-top:12px}
      @media(max-width:500px){.room{padding:24px 12px}h1{font-size:42px}.speech{font-size:17px;padding:18px}.intro{font-size:16px}}
      @media(prefers-reduced-motion:reduce){.stage .pet,.stage .pet *{animation:none!important}}
    </style><main class="room"><div class="eyebrow">un pedacito de Jules</div><h1>Bienvenida a Ju</h1>
    <p class="intro">Bienvenida a este pedacito de la cabeza de Jules. Elige una de las preguntitas de abajo. Con lo que conozco de él, intentaré responderte con su cariño y recordarte algo que él ha dejado muy claro: te ama muchísimo.</p>
    <p class="note">Una interpretación imaginaria inspirada en Jules, no sus pensamientos reales. No quedará registro de las conversaciones al salir.</p>
    <div class="stage"><div class="speech" role="status" aria-live="polite">Hola, soy Ju, un pedacito de la cabeza de Jules. Te cuento lo que él podría decir. Elige una preguntita para mí ♡</div>
    ${juPet}</div>
    <div class="suggestions"><button type="button">¿Qué me diría Jules si tengo un día triste?</button><button type="button">¿Jules me ama?</button><button type="button">¿Qué diría si discutimos?</button><button type="button">¿Qué diría en mi cumpleaños?</button><button type="button">¿Cómo imagina nuestro futuro juntos?</button><button type="button">¿Qué diría si lo extraño?</button><button type="button">¿Y si tarda en responder?</button><button type="button">¿Qué diría si estoy cansada?</button></div>
    <form hidden style="display:none"><textarea aria-label="Tu pregunta para Ju" placeholder="Pregúntale algo a Ju…" maxlength="1200" rows="1" required></textarea><button class="send" aria-label="Enviar pregunta" type="submit">↑</button></form>
    <details><summary>Nuestra conversación</summary><div class="history"></div></details><button class="reset" type="button">Empezar de nuevo</button></main>`
    this.controller = null
    root.querySelector('.pet').addEventListener('animationend', event => {
      if (event.animationName === 'happy' && !this.busy) root.querySelector('.stage').className = 'stage'
    })
    root.querySelector('form').addEventListener('submit', e => { e.preventDefault(); this.ask() })
    root.querySelector('textarea').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); this.ask() } })
    root.querySelectorAll('.suggestions button').forEach(button => button.addEventListener('click', () => { root.querySelector('textarea').value = button.textContent; this.ask() }))
    root.querySelector('.reset').addEventListener('click', () => { this.messages = []; root.querySelector('.history').replaceChildren(); root.querySelector('.speech').textContent = 'Soy Ju. Empecemos de nuevo: ¿qué quieres saber sobre Jules?' })
  }
  disconnectedCallback() { this.controller?.abort() }
  async ask() {
    const root = this.shadowRoot
    const input = root.querySelector('textarea')
    const question = input.value.trim()
    if (!question || this.busy) return
    this.busy = true
    root.querySelectorAll('button').forEach(b => b.disabled = true)
    const speech = root.querySelector('.speech')
    root.querySelector('.stage').className = 'stage thinking'
    this.gesture = ((this.gesture ?? -1) + 1) % 3
    root.querySelector('.stage').dataset.gesture = String(this.gesture)
    speech.textContent = 'Déjame pensarlo un poquito…'
    const conversation = [...this.messages.slice(-10), { role: 'user', content: question }]
    this.controller = new AbortController()
    try {
      const previous='';
      const data={reply:offlineReply(question,previous)};
      this.messages = [...conversation, { role: 'assistant', content: data.reply }]
      speech.textContent = data.reply
      input.value = ''
      root.querySelector('.history').replaceChildren(...this.messages.map(m => { const p = document.createElement('p'); p.textContent = `${m.role === 'user' ? 'Tú' : 'Ju'}: ${m.content}`; return p }))
      root.querySelector('.stage').className = 'stage talking'
    } catch (error) {
      if (error.name !== 'AbortError') speech.textContent = error.message || 'No pude conectar. Inténtalo otra vez.'
      root.querySelector('.stage').className = 'stage'
    } finally {
      this.busy = false
      root.querySelectorAll('button').forEach(b => b.disabled = false)
      
    }
  }
}
customElements.define('nirvana-ju', NirvanaJu)
