const randomBetween = (min, max) => min + Math.random() * (max - min)

window.addEventListener('nirvana-love', event => {
  const bubble = document.createElement('div')
  bubble.className = 'nirvana-love-bubble'
  bubble.setAttribute('role', 'status')
  bubble.textContent = 'te amo'
  document.body.append(bubble)

  const width = window.innerWidth
  const height = window.innerHeight
  const bubbleWidth = bubble.offsetWidth
  const bubbleHeight = bubble.offsetHeight
  const clampX = x => Math.max(8, Math.min(width - bubbleWidth - 8, x))
  const clampY = y => Math.max(12, Math.min(height - bubbleHeight - 12, y))
  const startX = clampX(event.detail.x + 20)
  const startY = clampY(event.detail.y - bubbleHeight - 12)
  const endX = clampX(randomBetween(12, width - bubbleWidth - 12))
  let endY = clampY(randomBetween(12, height - bubbleHeight - 12))
  if (Math.hypot(endX - startX, endY - startY) < Math.max(width, height) * .25) endY = clampY(startY - height * .5)
  const control1 = { x: clampX(startX + randomBetween(30, width * .45)), y: clampY(startY - randomBetween(50, height * .4)) }
  const control2 = { x: clampX(randomBetween(12, width - bubbleWidth - 12)), y: clampY(randomBetween(12, height - bubbleHeight - 12)) }
  const phase = randomBetween(0, Math.PI * 2)
  const sway = randomBetween(10, 24)
  const frequency = randomBetween(1, 2)
  const curve = (t, start, c1, c2, end) => (1 - t) ** 3 * start + 3 * (1 - t) ** 2 * t * c1 + 3 * (1 - t) * t ** 2 * c2 + t ** 3 * end
  const transform = (x, y, scale = 1) => `translate3d(${x}px, ${y}px, 0) scale(${scale})`
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches
  const frames = reducedMotion ? [
    { opacity: 0, transform: transform(startX, startY) },
    { opacity: 1, transform: transform(startX, startY), offset: .15 },
    { opacity: 1, transform: transform(startX, startY), offset: .8 },
    { opacity: 0, transform: transform(startX, startY) },
  ] : Array.from({ length: 73 }, (_, index) => {
    const t = index / 72
    const wave = Math.sin(t * Math.PI * 2 * frequency + phase) * Math.sin(Math.PI * t)
    const x = clampX(curve(t, startX, control1.x, control2.x, endX) + wave * sway)
    const y = clampY(curve(t, startY, control1.y, control2.y, endY) + Math.cos(t * Math.PI * 2 + phase) * Math.sin(Math.PI * t) * sway * .5)
    return {
      offset: t,
      opacity: Math.max(0, Math.min(1, t / .08, (1 - t) / .18)),
      transform: `${transform(x, y, .88 + .12 * Math.min(1, t / .1))} rotate(${wave * 3}deg)`,
    }
  })
  const animation = bubble.animate(frames, {
    duration: reducedMotion ? 2200 : randomBetween(7500, 11000),
    easing: reducedMotion ? 'ease-in-out' : 'linear',
    fill: 'both',
  })
  animation.finished.then(() => bubble.remove(), () => bubble.remove())
})
