// Birthday copy; preserve the expanding-text entrance animation.
const sequence = [
  ['intro-name', 'Bienvenida a tu pequeño espacio.', 400],
  ['intro-p1', 'Espero que lo disfrutes mucho y lo atesores tanto como lo atesoré yo haciendo este lugar para ti.', 500],
  ['intro-p2', 'Te amo con todo mi corazón. Feliz cumpleaños.', 400],
  ['intro-p3', 'Con amor, Jules (tu futuro esposo)', 0],
]
const page = document.documentElement
const shell = document.getElementById('nirvana-intro')
const root = document.getElementById('root')
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
let finished = false

function cleanup() {
  finished = true
  page.classList.remove('nirvana-intro-active')
  if (root) root.inert = false
  shell?.remove()
  clearTimeout(window.__nirvanaIntroTimeout)
}

async function reveal() {
  if (finished) return
  finished = true
  clearTimeout(window.__nirvanaIntroTimeout)
  try { localStorage.setItem('nirvana.raffi-intro.seen.v1', 'true') } catch { /* storage may be disabled */ }
  try {
    if (!reduced) {
      const copy = shell.querySelector('.intro-copy')
      await copy.animate([{transform:'translateX(0)',opacity:1},{transform:'translateX(min(15vw,190px))',opacity:0}],{duration:650,easing:'cubic-bezier(.22,1,.36,1)',fill:'forwards'}).finished
      if (root) root.style.visibility = 'visible'
      const animations = [shell.animate([{opacity:1},{opacity:0}],{duration:700,fill:'forwards'}).finished]
      if (root) animations.push(root.animate([{transform:'translateY(100vh) rotate(-1deg)',opacity:.4},{transform:'translateY(0) rotate(0deg)',opacity:1}],{duration:1100,easing:'cubic-bezier(.16,1,.3,1)'}).finished)
      await Promise.all(animations)
    }
  } finally {
    if (root) root.style.removeProperty('visibility')
    cleanup()
  }
}

function appendSegment(target, html) {
  const template = document.createElement('template')
  template.innerHTML = html
  const walker = document.createTreeWalker(template.content, NodeFilter.SHOW_TEXT)
  const texts = []
  while (walker.nextNode()) texts.push(walker.currentNode)
  const letters = []
  for (const text of texts) {
    const fragment = document.createDocumentFragment()
    for (const token of text.textContent.split(/(\s+)/)) {
      if (/^\s+$/.test(token)) {
        const space = document.createElement('span')
        space.className = 'intro-letter'
        space.textContent = token
        fragment.append(space)
        letters.push(space)
        continue
      }
      const word = document.createElement('span')
      word.className = 'intro-word'
      for (const character of token) {
        const letter = document.createElement('span')
        letter.className = 'intro-letter'
        letter.textContent = character
        word.append(letter)
        letters.push(letter)
      }
      fragment.append(word)
    }
    text.replaceWith(fragment)
  }
  target.append(template.content)
  return letters
}

async function start() {
  await window.__nirvanaEntryPromise
  if (!page.classList.contains('nirvana-intro-active')) { cleanup(); return }
  window.__nirvanaIntroTimeout = setTimeout(cleanup, 25000)
  root.inert = true
  shell.addEventListener('click', event => {
    if (event.target.closest('[data-enter]')) { event.preventDefault(); void reveal() }
  })
  document.addEventListener('keydown', event => {
    if (!finished && event.key === 'Escape') void reveal()
  })
  await Promise.race([document.fonts.load('380 18px RaffiIntro'), sleep(1500)])
  await sleep(100)
  for (const [id, html, pause] of sequence) {
    if (finished) return
    const target = document.getElementById(id)
    const letters = appendSegment(target, html)
    for (const letter of letters) {
      if (finished) return
      letter.classList.add('shown')
      if (!reduced) await sleep(20)
    }
    if (!reduced) await sleep(pause)
  }
  shell.querySelector('.intro-socials').classList.add('revealed')
  await sleep(reduced ? 1200 : 800)
  await reveal()
}
start().catch(error => { console.warn('Intro skipped:', error); cleanup() })
