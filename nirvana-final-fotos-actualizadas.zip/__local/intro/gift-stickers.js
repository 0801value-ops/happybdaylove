const dialogStyle = document.createElement('style')
dialogStyle.textContent = `
.sticker-photo-button{position:relative;min-width:0;min-height:0;aspect-ratio:1/1!important;box-sizing:border-box!important}
.sticker-photo-button>img{position:absolute;inset:12px;width:calc(100% - 24px)!important;height:calc(100% - 24px)!important;object-fit:contain!important}
.sticker-photo-button:hover{transform:translateY(-4px) rotate(-1deg);box-shadow:0 10px 24px rgba(42,34,25,.13)!important}
.sticker-photo-button:focus-visible{outline:3px solid #78bfd9;outline-offset:3px}
.sticker-download-toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0 12px}
.sticker-download-toolbar a{display:inline-flex;align-items:center;padding:10px 16px;border:1px solid #b8d9e3;border-radius:999px;background:#e7f3f7;color:#29414c;text-decoration:none;font-family:inherit;font-size:15px;line-height:1.3}
.sticker-download-toolbar a:hover{background:#d5ebf3}
.sticker-import-help{font-size:14px;line-height:1.6;color:#706971;max-width:700px;margin-bottom:20px}
.sticker-import-help summary{cursor:pointer;text-decoration:underline;text-underline-offset:3px}
.sticker-import-help p{margin:8px 0}
.personal-sticker-name{margin:-8px 0 18px;font-size:15px;letter-spacing:.025em;color:#81737a;text-align:center}
@media(min-width:521px){.stickers-for-you-grid>.sticker-photo-button:last-child:nth-child(3n+1){grid-column:2}}
.personal-sticker-image{background:repeating-conic-gradient(#e8e8e8 0% 25%,#f8f8f8 0% 50%) 50% / 24px 24px}
.personal-gift-overlay{position:fixed;inset:0;z-index:5000;display:grid;place-items:center;padding:22px;background:rgba(45,35,43,.52);backdrop-filter:blur(8px);animation:gift-overlay-in .2s ease both}
.personal-gift-dialog{position:relative;box-sizing:border-box;width:min(760px,94vw);max-height:92vh;overflow:auto;padding:26px;border:1px solid rgba(80,60,70,.12);border-radius:20px;background:linear-gradient(145deg,#fff 0%,#fffaf6 100%);box-shadow:0 24px 80px rgba(37,24,33,.24);text-align:center;color:#332b35;font-family:inherit;animation:gift-dialog-in .28s cubic-bezier(.2,.8,.2,1) both}
.personal-gift-dialog h2{margin:5px 42px 18px;font-size:25px;font-weight:500}
.personal-gift-dialog img{display:block;max-width:100%;max-height:68vh;margin:0 auto;object-fit:contain;border-radius:10px}
.personal-gift-close{position:absolute;right:14px;top:13px;width:38px;height:38px;border:0;border-radius:50%;background:#f5edf1;color:#55434c;font:inherit;font-size:25px;line-height:1;cursor:pointer}
.personal-gift-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-top:18px}
.personal-gift-download{display:inline-flex;align-items:center;justify-content:center;padding:10px 18px;border-radius:999px;background:#b9e4f1;color:#24414d;text-decoration:none;font-size:14px;font-weight:600}
.personal-gift-note{max-width:420px;margin:12px auto;color:#756873;line-height:1.65}
.personal-gift-present{position:relative;width:116px;height:104px;margin:10px auto 18px;animation:gift-float 3s ease-in-out infinite}
.personal-gift-present .birthday-gift-art{margin:auto}
.birthday-gift-label{max-width:145px;line-height:1.45;text-wrap:balance}
@keyframes gift-overlay-in{from{opacity:0}to{opacity:1}}
@keyframes gift-dialog-in{from{opacity:0;transform:translateY(12px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
@media(prefers-reduced-motion:reduce){.personal-gift-overlay,.personal-gift-dialog,.personal-gift-present{animation:none!important}}
@media(max-width:520px){.stickers-for-you-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important}.personal-gift-dialog{padding:20px 14px}.sticker-download-toolbar a{font-size:13px;padding:9px 12px}}
`
document.head.append(dialogStyle)

const openedGiftsKey = 'nirvana.gifts.opened.v2'
const openedGifts = new Set()
try {
  const saved = JSON.parse(localStorage.getItem(openedGiftsKey) || '[]')
  if (Array.isArray(saved)) saved.filter(id => /^gift-\d{2}$/.test(id)).forEach(id => openedGifts.add(id))
} catch {}

function revealGiftName(button) {
  if (!openedGifts.has(button.dataset.giftId)) return
  const number = button.dataset.giftId.replace('gift-', '')
  const label = button.querySelector('.birthday-gift-label')
  const title = `${number} · ${button.dataset.giftName}`
  if (label && label.textContent !== title) label.textContent = title
  button.classList.remove('is-opened')
  button.setAttribute('aria-label', `Volver a abrir regalo ${number}: ${button.dataset.giftName}`)
}

function restoreOpenedGifts() {
  document.querySelectorAll('.birthday-gift-button').forEach(revealGiftName)
}

// React mounts this page again after navigation; keep previously revealed titles.
new MutationObserver(records => {
  if (records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 &&
      (node.matches('.birthday-gift-button') || node.querySelector('.birthday-gift-button'))))) {
    restoreOpenedGifts()
  }
}).observe(document.body, { childList: true, subtree: true })
restoreOpenedGifts()

function closeDialog() {
  document.querySelectorAll('.birthday-gift-button.is-opened').forEach(button => button.classList.remove('is-opened'))
  document.querySelector('.personal-gift-overlay')?.remove()
}

function createDialog(title) {
  closeDialog()
  const overlay = document.createElement('div')
  overlay.className = 'personal-gift-overlay'
  overlay.addEventListener('click', event => {
    if (event.target === overlay) closeDialog()
  })
  const dialog = document.createElement('section')
  dialog.className = 'personal-gift-dialog'
  dialog.setAttribute('role', 'dialog')
  dialog.setAttribute('aria-modal', 'true')
  dialog.setAttribute('aria-label', title)
  const close = document.createElement('button')
  close.type = 'button'
  close.className = 'personal-gift-close'
  close.setAttribute('aria-label', 'Cerrar')
  close.textContent = '×'
  close.addEventListener('click', closeDialog)
  const heading = document.createElement('h2')
  heading.textContent = title
  dialog.append(close, heading)
  overlay.append(dialog)
  document.body.append(overlay)
  close.focus()
  return dialog
}

window.addEventListener('nirvana-open-sticker', event => {
  const { alt, id, src, name } = event.detail ?? {}
  if (!id || !src) return
  const dialog = createDialog('Stickers for you')
  const displayName = name || id
  const caption = document.createElement('p')
  caption.className = 'personal-sticker-name'
  caption.textContent = displayName
  const image = document.createElement('img')
  image.src = src
  image.alt = alt || 'Sticker'
  image.className = 'personal-sticker-image'
  const actions = document.createElement('div')
  actions.className = 'personal-gift-actions'
  for (const [label, href, filename] of [
    ['Sticker PNG sin fondo', `/__local/stickers/${id}.png?download=1`, `${displayName}.png`],
    ['Foto normal PNG', `/__local/sticker-photos/${id}.png?download=1`, `${displayName}-foto.png`],
    ['Sticker para WhatsApp', `/__local/whatsapp-stickers/${id}.webp?download=1`, `${displayName}.webp`],
  ]) {
    const download = document.createElement('a')
    download.className = 'personal-gift-download'
    download.href = href
    download.download = filename
    download.textContent = label
    actions.append(download)
  }
  dialog.append(caption, image, actions)
})

function showGift(button) {
  const number = button.dataset.giftId?.replace('gift-', '') || ''
  const name = button.dataset.giftName || 'Un regalito para ti'
  const dialog = createDialog(`${number} · ${name}`)
  if (button.dataset.giftPhoto) {
    const photo = document.createElement('img')
    photo.src = button.dataset.giftPhoto
    photo.alt = name
    dialog.append(photo)
    return
  }
  const present = document.createElement('div')
  present.className = 'personal-gift-present'
  present.style.setProperty('--gift-color', button.style.getPropertyValue('--gift-color'))
  present.style.setProperty('--gift-ribbon', button.style.getPropertyValue('--gift-ribbon'))
  const art = button.querySelector('.birthday-gift-art')?.cloneNode(true)
  if (art) {
    art.classList.remove('is-opening')
    present.append(art)
  }
  const note = document.createElement('p')
  note.className = 'personal-gift-note'
  note.textContent = 'Este regalito está esperando su foto. Cuando me la envíes, la pondré aquí.'
  dialog.append(present, note)
}

document.addEventListener('click', event => {
  const button = event.target.closest('.birthday-gift-button')
  if (!button || button.disabled) return
  button.disabled = true
  button.setAttribute('aria-busy', 'true')
  button.classList.remove('is-opened')
  button.classList.add('is-opening')
  window.setTimeout(() => {
    button.classList.remove('is-opening')
    button.classList.add('is-opened')
    button.disabled = false
    button.removeAttribute('aria-busy')
    openedGifts.add(button.dataset.giftId)
    try { localStorage.setItem(openedGiftsKey, JSON.stringify([...openedGifts])) } catch {}
    revealGiftName(button)
    showGift(button)
  }, 1350)
})

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeDialog()
})
